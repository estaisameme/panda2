public class Cat extends Animal {

  //TODO:

}
